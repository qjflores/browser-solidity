# Automatic build
Built website from `6b8842f`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `browser-solidity-6b8842f.zip`.
